import React from "react";
import "./styles.css";

function isEmailValid(str)
{
  const pattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
  return pattern.test(str);
}

function isPwdValid(str)
{
const pattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
return pattern.test(str);
}


function validate(value,name){
  let errMsg='';
  if(value===''){
    errMsg = "Field cannot be blank";
}else if(name!=='email' && (value.length<3 || value.length>12)) {
    errMsg = `${name} must be atleast 3 chars and atmost 12 chars long.`;

  }else
    if(name==='email'){
    if(!isEmailValid(value)){
        errMsg="Invlaid email address";
    }
}else if(name==='pwd'){
      // if(value.length<9) errMsg = 'Password must be atleast 8 characters long.'
        if(!isPwdValid(value)){
          errMsg='Password must contain atleast 1 special character, 1 uppercase letter, 1 lowercase letter, 1 numberic digit with minimum 0f 8 characters. '
        }
}

return errMsg;
}
export default class App extends React.Component {

  state={
      fname:"",
      lname:"",
      email:'',
      pwd:''
  }
  handleBlur=(event)=>{

    let {name,value} = event.target;
    value = value.trim(); 
    const errMsg =  validate(value,name);
     this.setState({[name]:errMsg});
  }


  handleSubmit=(event)=>{
    event.preventDefault();

    const arr = [...event.target.elements];

    arr.forEach(ele=>{
      if(ele.type!=='submit'){
          const errMsg = validate(ele.value,ele.name);
          // console.log(errMsg);
          this.setState({[ele.name]:errMsg});
      }
        
    })
    // const {fname,lname,email,pwd} = this.state;
    // const arr = [fname,lname,email,pwd];
    // arr.forEach()
  }
  render(){
  return (
    <div className="container">
      <div className="header">
        <h2>Create Account</h2>
      </div>
        <form className="form" onSubmit={this.handleSubmit}>
  
            <div className="inpt" id="fname">
              <label>First name:</label>
              <input autoComplete="off" name="fname" onChange={this.handleBlur} type="text"/>
              <span>{this.state.fname}</span>
            </div>
            <div className="inpt" id="lname">
              <label>Last name:</label>
              <input autoComplete="off" name="lname" onChange={this.handleBlur} type="text"/>
              <span>{this.state.lname}</span>
            </div>
  
            <div className="inpt">
              <label>Email:</label>
              <input autoComplete="off" name="email" onChange={this.handleBlur} type="email"/>
              <span>{this.state.email}</span>
            </div>
            <div className="inpt">
              <label>Password:</label>
              <input autoComplete="off" name="pwd" onChange={this.handleBlur} type="password"/>
              <span>{this.state.pwd}</span>
            </div>
              <button type="submit">Register</button>
        </form>
    </div>
  );
}
}
